﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiP507.DAL;
using WebApiP507.Models;

namespace WebApiP507.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly AppDbContext _db;
        public PostController(AppDbContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Get All Post
        /// </summary>
        /// <returns></returns>
        // GET: api/Post
        [HttpGet]
        public ActionResult<IEnumerable<Post>> Get()
        {
            return _db.Posts;
        }

        /// <summary>
        /// Get Post equal Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: api/Post/5
        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<Post>> Get(int id)
        {
            Post post =await _db.Posts.FindAsync(id);
            if (post == null) return NotFound();
            return post;
        }

        /// <summary>
        /// Create Post
        /// </summary>
        /// <param name="post"></param>
        /// <returns></returns>
        // POST: api/Post
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] Post post)
        {
            await _db.Posts.AddAsync(post);
            await _db.SaveChangesAsync();

            return CreatedAtAction("Get", new { id = post.Id },post);
        }

        /// <summary>
        /// Update Post
        /// </summary>
        /// <param name="id"></param>
        /// <param name="post"></param>
        /// <returns></returns>
        // PUT: api/Post/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Post post)
        {
            if (!_db.Posts.Any(p => p.Id == id)) return NotFound();
            if (id != post.Id) return BadRequest();

            Post postDb =await _db.Posts.FindAsync(id);
            postDb.Title = post.Title;
            postDb.Body = post.Body;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>
        /// Delete Post
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Post post =await _db.Posts.FindAsync(id);

            if (post == null) return NotFound();

            _db.Posts.Remove(post);
            await _db.SaveChangesAsync();

            return NoContent();
        }
    }
}
